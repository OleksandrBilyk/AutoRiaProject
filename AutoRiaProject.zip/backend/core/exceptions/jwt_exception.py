class JWTException(Exception):
    pass
